package package2;

import package1.class1;

public class class2 extends class1 {

	protected void testmethod() {
		System.out.println("This is class1 method");
	}
	public static void main(String[] args) {
		class1 object_test=new class2();
		object_test.testmethod();
	}

}
