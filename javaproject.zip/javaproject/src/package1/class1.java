package package1;

public class class1 {
 protected void testmethod(){
	 System.out.println("This is class1 method");
 }
}
